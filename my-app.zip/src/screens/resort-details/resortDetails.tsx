import React from 'react';

function ResortDetails() {
  return (
<h1>ResortDetails</h1>
  );
}

export default ResortDetails;
