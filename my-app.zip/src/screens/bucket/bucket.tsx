import React from 'react';


function Bucket() {
  return (
<h1>BUCKET</h1>
  );
}

export default Bucket;
